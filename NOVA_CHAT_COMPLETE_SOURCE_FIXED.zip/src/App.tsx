import { useEffect, useState } from "react";
import type { FormEvent } from "react";
import PhoneInput from "react-phone-number-input";
import type { E164Number } from "libphonenumber-js/core";
import "react-phone-number-input/style.css";
import { isSupabaseConfigured, supabase } from "./lib/supabase";

type Screen = "phone" | "otp" | "profile" | "home";

export default function App() {
  const [screen, setScreen] = useState<Screen>("phone");
  const [phone, setPhone] = useState<E164Number | undefined>();
  const [otp, setOtp] = useState("");
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [userPhone, setUserPhone] = useState("");

  useEffect(() => {
    const restore = async () => {
      if (!supabase) return;
      const { data } = await supabase.auth.getSession();
      if (data.session?.user) {
        setUserPhone(data.session.user.phone ?? "");
        setScreen("profile");
      }
    };
    void restore();
  }, []);

  async function sendOtp(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setMessage("");
    if (!supabase || !phone) {
      setMessage(!isSupabaseConfigured ? "إعدادات Supabase غير مكتملة." : "اكتب رقم الهاتف أولاً.");
      return;
    }
    setBusy(true);
    const { error } = await supabase.auth.signInWithOtp({
      phone,
      options: { shouldCreateUser: true }
    });
    setBusy(false);
    if (error) setMessage(error.message);
    else {
      setUserPhone(phone);
      setScreen("otp");
      setMessage("تم إرسال رمز التحقق إذا كان الرقم مدعوماً.");
    }
  }

  async function verifyOtp(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!supabase || !phone || otp.trim().length !== 6) {
      setMessage("اكتب رمز التحقق المكوّن من 6 أرقام.");
      return;
    }
    setBusy(true);
    const { error } = await supabase.auth.verifyOtp({
      phone,
      token: otp.trim(),
      type: "sms"
    });
    setBusy(false);
    if (error) setMessage(error.message);
    else setScreen("profile");
  }

  async function saveProfile(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!supabase) return;
    const { data } = await supabase.auth.getUser();
    if (!data.user) {
      setMessage("انتهت الجلسة. سجّل الدخول مرة أخرى.");
      setScreen("phone");
      return;
    }
    const cleanName = name.trim();
    if (!cleanName) {
      setMessage("اكتب اسمك للمتابعة.");
      return;
    }
    setBusy(true);
    const { error } = await supabase.from("profiles").upsert({
      id: data.user.id,
      display_name: cleanName,
      phone: data.user.phone ?? userPhone
    });
    setBusy(false);
    if (error) setMessage(error.message);
    else setScreen("home");
  }

  async function signOut() {
    if (supabase) await supabase.auth.signOut();
    setPhone(undefined);
    setOtp("");
    setName("");
    setMessage("");
    setScreen("phone");
  }

  return (
    <main className="page">
      <section className="card">
        <div className="brand-mark">N</div>
        <p className="eyebrow">WELCOME TO</p>
        <h1>NOVA CHAT</h1>
        <p className="subtitle">تواصل بسهولة وأمان</p>

        {!isSupabaseConfigured && (
          <div className="notice">يلزم إضافة VITE_SUPABASE_URL و VITE_SUPABASE_ANON_KEY في GitHub Secrets ثم إعادة البناء.</div>
        )}

        {screen === "phone" && (
          <form onSubmit={sendOtp}>
            <label>رقم الهاتف</label>
            <PhoneInput
              international
              defaultCountry="EG"
              value={phone}
              onChange={setPhone}
              placeholder="أدخل رقم هاتفك"
            />
            <button disabled={busy || !phone}>{busy ? "جارٍ الإرسال..." : "إرسال رمز التحقق"}</button>
          </form>
        )}

        {screen === "otp" && (
          <form onSubmit={verifyOtp}>
            <label>رمز التحقق</label>
            <input
              value={otp}
              onChange={(event) => setOtp(event.target.value.replace(/\D/g, "").slice(0, 6))}
              inputMode="numeric"
              autoComplete="one-time-code"
              placeholder="••••••"
              maxLength={6}
            />
            <button disabled={busy || otp.length !== 6}>{busy ? "جارٍ التحقق..." : "تأكيد الرمز"}</button>
            <button type="button" className="secondary" onClick={() => setScreen("phone")}>تغيير الرقم</button>
          </form>
        )}

        {screen === "profile" && (
          <form onSubmit={saveProfile}>
            <label>اسمك داخل التطبيق</label>
            <input value={name} onChange={(event) => setName(event.target.value)} placeholder="اكتب اسمك" />
            <button disabled={busy}>{busy ? "جارٍ الحفظ..." : "متابعة"}</button>
          </form>
        )}

        {screen === "home" && (
          <div className="home">
            <h2>أهلاً بيك في NOVA CHAT</h2>
            <p>تم تسجيل الدخول بنجاح.</p>
            <div className="empty-chat">قائمة المحادثات ستظهر هنا بعد تفعيل نظام الرسائل.</div>
            <button className="secondary" onClick={signOut}>تسجيل الخروج</button>
          </div>
        )}

        {message && <p className="message" role="status">{message}</p>}
        <p className="footer">NOVA CHAT · تواصل بلا حدود</p>
      </section>
    </main>
  );
}
