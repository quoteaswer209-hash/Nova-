# NOVA CHAT - النسخة المصححة

## محتويات النسخة
- React + TypeScript + Vite.
- Capacitor 7 لإعداد تطبيق Android.
- تسجيل دخول برقم الهاتف والتحقق عبر OTP باستخدام Supabase.
- حفظ اسم المستخدم في جدول `profiles`.

## إعداد GitHub
أضف Repository Secrets بالأسماء التالية:
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`

استخدم رابط مشروع Supabase ومفتاح `anon` القديم أو `publishable` من إعدادات API.
لا تستخدم `service_role` ولا تضع Vonage API Secret في التطبيق أو GitHub.

في workflow اجعل خطوة بناء الويب هكذا:

```yaml
- name: Build Web Project
  env:
    VITE_SUPABASE_URL: ${{ secrets.VITE_SUPABASE_URL }}
    VITE_SUPABASE_ANON_KEY: ${{ secrets.VITE_SUPABASE_ANON_KEY }}
  run: |
    cd "$PROJECT_DIR"
    npm run build
```

## إعداد قاعدة البيانات
افتح Supabase SQL Editor وشغّل محتوى `supabase/schema.sql` مرة واحدة.

## البناء
يتطلب Node.js 22 و Java 21. بعد فك الضغط:
```bash
npm install
npm run build
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```

## ملاحظات مهمة
- تم إصلاح استيراد `FormEvent` ليكون `import type`.
- تم حذف الخاصية القديمة `bundledWebRuntime` غير المدعومة في Capacitor 7.
- هذه النسخة تحتوي على تسجيل OTP وملف شخصي وواجهة بداية فقط.
- المحادثات الحقيقية والمجموعات والمكالمات والإشعارات ليست مفعلة في هذه النسخة.
- إرسال OTP يعتمد على إعداد Phone Auth ومزود SMS في Supabase، ولا يمكن ضمان عمله قبل اختبار إعدادات المشروع.
