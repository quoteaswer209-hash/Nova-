import { useEffect, useMemo, useState } from "react";
import type { FormEvent } from "react";
import { Capacitor } from "@capacitor/core";
import { Contacts } from "@capacitor-community/contacts";
import type { Contact } from "@capacitor-community/contacts";
import { parsePhoneNumberFromString } from "libphonenumber-js";
import PhoneInput from "react-phone-number-input";
import type { E164Number } from "libphonenumber-js/core";
import "react-phone-number-input/style.css";
import { isSupabaseConfigured, supabase } from "./lib/supabase";

type Screen = "phone" | "otp" | "profile" | "home" | "contacts";
type MatchedUser = { phone: string; display_name: string };
type DeviceContact = { id: string; name: string; phone: string; matched?: MatchedUser };

export default function App() {
  const [screen, setScreen] = useState<Screen>("phone");
  const [phone, setPhone] = useState<E164Number | undefined>();
  const [otp, setOtp] = useState("");
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [userPhone, setUserPhone] = useState("");
  const [contacts, setContacts] = useState<DeviceContact[]>([]);
  const [search, setSearch] = useState("");
  const [contactsLoaded, setContactsLoaded] = useState(false);

  useEffect(() => {
    const restore = async () => {
      if (!supabase) return;
      const { data } = await supabase.auth.getSession();
      if (data.session?.user) {
        setUserPhone(data.session.user.phone ?? "");
        setScreen("profile");
      }
    };
    void restore();
  }, []);

  async function sendOtp(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setMessage("");
    if (!supabase || !phone) {
      setMessage(!isSupabaseConfigured ? "إعدادات Supabase غير مكتملة." : "اكتب رقم الهاتف أولاً.");
      return;
    }
    setBusy(true);
    const { error } = await supabase.auth.signInWithOtp({ phone, options: { shouldCreateUser: true } });
    setBusy(false);
    if (error) setMessage(error.message);
    else { setUserPhone(phone); setScreen("otp"); setMessage("تم إرسال رمز التحقق إذا كان الرقم مدعوماً."); }
  }

  async function verifyOtp(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!supabase || !phone || otp.trim().length !== 6) { setMessage("اكتب رمز التحقق المكوّن من 6 أرقام."); return; }
    setBusy(true);
    const { error } = await supabase.auth.verifyOtp({ phone, token: otp.trim(), type: "sms" });
    setBusy(false);
    if (error) setMessage(error.message); else setScreen("profile");
  }

  async function saveProfile(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!supabase) return;
    const { data } = await supabase.auth.getUser();
    if (!data.user) { setMessage("انتهت الجلسة. سجّل الدخول مرة أخرى."); setScreen("phone"); return; }
    const cleanName = name.trim();
    if (!cleanName) { setMessage("اكتب اسمك للمتابعة."); return; }
    setBusy(true);
    const { error } = await supabase.from("profiles").upsert({
      id: data.user.id, display_name: cleanName, phone: data.user.phone ?? userPhone
    });
    setBusy(false);
    if (error) setMessage(error.message); else setScreen("home");
  }

  function normalizePhone(raw?: string): string | null {
    if (!raw) return null;
    try {
      const parsed = parsePhoneNumberFromString(raw, "EG");
      return parsed?.isValid() ? parsed.number : null;
    } catch { return null; }
  }

  async function loadContacts() {
    setMessage("");
    if (!supabase) { setMessage("إعدادات Supabase غير مكتملة."); return; }
    if (!Capacitor.isNativePlatform()) { setMessage("جهات الاتصال متاحة من تطبيق Android المثبّت فقط."); return; }
    setBusy(true);
    try {
      const permission = await Contacts.getPermissions();
      // The native read call can trigger the Android permission prompt when access is not granted yet.
      // If the user has denied access, the catch block explains how to enable it in Settings.
      const result = await Contacts.getContacts();
      const local: DeviceContact[] = [];
      const seen = new Set<string>();
      for (const contact of (result.contacts ?? []) as Contact[]) {
        const displayName = contact.displayName?.trim() || "بدون اسم";
        for (const item of contact.phoneNumbers ?? []) {
          const normalized = normalizePhone(item.number);
          if (!normalized || seen.has(normalized)) continue;
          seen.add(normalized);
          local.push({ id: `${contact.contactId}-${normalized}`, name: displayName, phone: normalized });
        }
      }
      setContacts(local);
      setContactsLoaded(true);
      if (local.length === 0) { setMessage("لم يتم العثور على أرقام صالحة في جهات الاتصال."); setBusy(false); return; }

      // The user explicitly starts this action after seeing the disclosure below.
      const numbers = [...new Set(local.map((item) => item.phone))].slice(0, 300);
      const { data: matches, error } = await supabase.rpc("match_contacts", { p_phones: numbers });
      if (error) {
        setMessage("تم تحميل جهات الاتصال، لكن مطابقة مستخدمي NOVA CHAT تحتاج تشغيل تحديث قاعدة البيانات من ملف supabase/schema.sql.");
      } else {
        const byPhone = new Map<string, MatchedUser>((matches ?? []).map((row: MatchedUser) => [row.phone, row]));
        setContacts(local.map((item) => ({ ...item, matched: byPhone.get(item.phone) })));
        setMessage(`تم تحديث ${local.length} رقم من جهات اتصالك.`);
      }
    } catch (error) {
      const detail = error instanceof Error ? error.message : "تعذر قراءة جهات الاتصال";
      setMessage(detail);
    } finally { setBusy(false); }
  }

  const visibleContacts = useMemo(() => contacts.filter((item) =>
    `${item.name} ${item.phone}`.toLowerCase().includes(search.toLowerCase())
  ), [contacts, search]);

  async function signOut() {
    if (supabase) await supabase.auth.signOut();
    setPhone(undefined); setOtp(""); setName(""); setMessage(""); setContacts([]); setContactsLoaded(false); setScreen("phone");
  }

  return (
    <main className="page">
      <section className="card">
        <div className="brand-mark">N</div>
        <p className="eyebrow">WELCOME TO</p>
        <h1>NOVA CHAT</h1>
        <p className="subtitle">تواصل بسهولة وأمان</p>

        {!isSupabaseConfigured && <div className="notice">يلزم إضافة VITE_SUPABASE_URL و VITE_SUPABASE_ANON_KEY في GitHub Secrets ثم إعادة البناء.</div>}

        {screen === "phone" && <form onSubmit={sendOtp}>
          <label>رقم الهاتف</label>
          <PhoneInput international defaultCountry="EG" value={phone} onChange={setPhone} placeholder="أدخل رقم هاتفك" />
          <button disabled={busy || !phone}>{busy ? "جارٍ الإرسال..." : "إرسال رمز التحقق"}</button>
        </form>}

        {screen === "otp" && <form onSubmit={verifyOtp}>
          <label>رمز التحقق</label>
          <input value={otp} onChange={(event) => setOtp(event.target.value.replace(/\D/g, "").slice(0, 6))} inputMode="numeric" autoComplete="one-time-code" placeholder="••••••" maxLength={6} />
          <button disabled={busy || otp.length !== 6}>{busy ? "جارٍ التحقق..." : "تأكيد الرمز"}</button>
          <button type="button" className="secondary" onClick={() => setScreen("phone")}>تغيير الرقم</button>
        </form>}

        {screen === "profile" && <form onSubmit={saveProfile}>
          <label>اسمك داخل التطبيق</label>
          <input value={name} onChange={(event) => setName(event.target.value)} placeholder="اكتب اسمك" />
          <button disabled={busy}>{busy ? "جارٍ الحفظ..." : "متابعة"}</button>
        </form>}

        {screen === "home" && <div className="home">
          <h2>أهلاً بيك في NOVA CHAT</h2>
          <p>تم تسجيل الدخول بنجاح.</p>
          <button onClick={() => { setMessage(""); setScreen("contacts"); }}>جهات الاتصال</button>
          <div className="empty-chat">المحادثات ستظهر هنا بعد تفعيل نظام الرسائل.</div>
          <button className="secondary" onClick={signOut}>تسجيل الخروج</button>
        </div>}

        {screen === "contacts" && <div className="contacts-view">
          <div className="contacts-heading"><button type="button" className="back-button" onClick={() => setScreen("home")}>رجوع</button><h2>جهات الاتصال</h2></div>
          <p className="privacy-note">عند الضغط على تحديث، سيقرأ التطبيق الأسماء والأرقام بعد إذنك ويرسل الأرقام إلى Supabase لمطابقتها مع مستخدمي NOVA CHAT. لا نعرض دفتر أرقامك للآخرين.</p>
          <button onClick={loadContacts} disabled={busy}>{busy ? "جارٍ التحديث..." : contactsLoaded ? "تحديث جهات الاتصال" : "السماح وعرض جهات الاتصال"}</button>
          {contacts.length > 0 && <>
            <input className="search-input" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="ابحث بالاسم أو الرقم" />
            <div className="contact-count">{visibleContacts.length} جهة اتصال</div>
            <div className="contact-list">{visibleContacts.map((item) => <div className="contact-row" key={item.id}>
              <div className="avatar">{item.name.slice(0, 1)}</div>
              <div className="contact-info"><strong>{item.name}</strong><span>{item.phone}</span></div>
              {item.matched ? <span className="badge online">على NOVA</span> : <button className="invite-button" onClick={() => setMessage("ميزة الدعوة عبر مشاركة رابط التطبيق ستضاف لاحقاً.")}>دعوة</button>}
            </div>)}</div>
          </>}
          {contacts.length === 0 && <div className="empty-chat">اضغط على الزر لقراءة جهات الاتصال من هاتفك.</div>}
        </div>}

        {message && <p className="message" role="status">{message}</p>}
        <p className="footer">NOVA CHAT · تواصل بلا حدود</p>
      </section>
    </main>
  );
}
