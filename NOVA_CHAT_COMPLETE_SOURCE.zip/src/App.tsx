import { FormEvent, useEffect, useState } from "react";
import type { Session } from "@supabase/supabase-js";
import PhoneInput from "react-phone-number-input";
import type { E164Number } from "libphonenumber-js";
import {
  ArrowLeft, Check, ChevronLeft, Globe2, LockKeyhole, LogOut,
  MessageCircle, Moon, ShieldCheck, Sparkles, Sun, Users, Video, Wifi
} from "lucide-react";
import { isSupabaseConfigured, supabase } from "./lib/supabase";

type Profile = { id: string; phone: string | null; display_name: string | null };

const demoChats = [
  { name: "فريق NOVA", message: "أهلاً بك في نوفا شات 👋", time: "الآن", initials: "N", color: "violet" },
  { name: "محادثاتك", message: "ستظهر رسائلك هنا بعد ربط المحادثات", time: "—", initials: "م", color: "blue" },
  { name: "الأصدقاء", message: "ابدأ بإضافة جهات اتصالك", time: "—", initials: "ص", color: "green" }
];

export default function App() {
  const [session, setSession] = useState<Session | null>(null);
  const [loadingSession, setLoadingSession] = useState(true);
  const [phone, setPhone] = useState<E164Number | undefined>();
  const [otp, setOtp] = useState("");
  const [otpSent, setOtpSent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");
  const [noticeError, setNoticeError] = useState(false);
  const [seconds, setSeconds] = useState(0);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [displayName, setDisplayName] = useState("");
  const [profileBusy, setProfileBusy] = useState(false);
  const [dark, setDark] = useState(true);

  useEffect(() => {
    if (!supabase) {
      setLoadingSession(false);
      return;
    }
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setLoadingSession(false);
    });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      setSession(nextSession);
    });
    return () => listener.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (!session || !supabase) {
      setProfile(null);
      return;
    }
    let active = true;
    supabase.from("profiles").select("id, phone, display_name").eq("id", session.user.id).maybeSingle()
      .then(({ data, error }) => {
        if (!active) return;
        if (error) {
          setNotice("تم تسجيل الدخول، لكن جدول profiles غير جاهز. نفّذ ملف SQL المرفق في Supabase.");
          setNoticeError(true);
          return;
        }
        setProfile(data as Profile | null);
        if (data?.display_name) setDisplayName(data.display_name);
      });
    return () => { active = false; };
  }, [session]);

  useEffect(() => {
    if (seconds <= 0) return;
    const timer = window.setTimeout(() => setSeconds((s) => s - 1), 1000);
    return () => window.clearTimeout(timer);
  }, [seconds]);

  function showMessage(message: string, error = false) {
    setNotice(message);
    setNoticeError(error);
  }

  async function sendOtp(event: FormEvent) {
    event.preventDefault();
    if (!supabase || !phone) return;
    setBusy(true);
    showMessage("");
    const { error } = await supabase.auth.signInWithOtp({
      phone,
      options: { shouldCreateUser: true }
    });
    setBusy(false);
    if (error) {
      showMessage(error.message, true);
      return;
    }
    setOtpSent(true);
    setSeconds(60);
    showMessage("تم إرسال رمز التحقق. افحص رسائل SMS.");
  }

  async function verifyOtp(event: FormEvent) {
    event.preventDefault();
    if (!supabase || !phone) return;
    if (!/^\d{6}$/.test(otp)) {
      showMessage("اكتب رمز التحقق المكوّن من 6 أرقام.", true);
      return;
    }
    setBusy(true);
    showMessage("");
    const { data, error } = await supabase.auth.verifyOtp({
      phone,
      token: otp,
      type: "sms"
    });
    setBusy(false);
    if (error) {
      showMessage(error.message, true);
      return;
    }
    setSession(data.session);
    showMessage("تم التحقق بنجاح.");
  }

  async function resendOtp() {
    if (!supabase || !phone || seconds > 0 || busy) return;
    setBusy(true);
    const { error } = await supabase.auth.signInWithOtp({ phone, options: { shouldCreateUser: true } });
    setBusy(false);
    if (error) {
      showMessage(error.message, true);
      return;
    }
    setSeconds(60);
    showMessage("تم إرسال رمز جديد.");
  }

  async function saveProfile(event: FormEvent) {
    event.preventDefault();
    if (!supabase || !session) return;
    const name = displayName.trim();
    if (name.length < 2) {
      showMessage("اكتب اسمًا مكوّنًا من حرفين على الأقل.", true);
      return;
    }
    setProfileBusy(true);
    const { data, error } = await supabase.from("profiles").upsert({
      id: session.user.id,
      phone: session.user.phone ?? phone ?? null,
      display_name: name,
      updated_at: new Date().toISOString()
    }).select("id, phone, display_name").single();
    setProfileBusy(false);
    if (error) {
      showMessage("تعذّر حفظ الملف الشخصي. تأكد من تنفيذ ملف supabase/schema.sql. " + error.message, true);
      return;
    }
    setProfile(data as Profile);
    showMessage("أهلاً بك في NOVA CHAT!");
  }

  async function logout() {
    if (!supabase) return;
    await supabase.auth.signOut();
    setSession(null);
    setProfile(null);
    setOtp("");
    setOtpSent(false);
    setPhone(undefined);
    showMessage("تم تسجيل الخروج.");
  }

  if (!isSupabaseConfigured) {
    return <div className="app-shell" dir="rtl"><div className="config-card">
      <div className="brand-mark"><Sparkles size={28} /></div>
      <h1>NOVA CHAT</h1>
      <h2>التطبيق يحتاج إعداد الاتصال</h2>
      <p>لم يتم تمرير إعدادات Supabase أثناء البناء. أضف أسرار GitHub الموضحة في README ثم أعد بناء APK.</p>
      <div className="code-line">VITE_SUPABASE_URL</div>
      <div className="code-line">VITE_SUPABASE_ANON_KEY</div>
    </div></div>;
  }

  if (loadingSession) return <div className="loading-screen"><div className="loader" /><span>جاري تجهيز NOVA CHAT...</span></div>;

  if (!session) {
    return <main className={`app-shell ${dark ? "dark" : "light"}`} dir="rtl">
      <button className="theme-toggle" onClick={() => setDark(!dark)} aria-label="تغيير المظهر">
        {dark ? <Sun size={19} /> : <Moon size={19} />}
      </button>
      <section className="auth-layout">
        <div className="auth-visual">
          <div className="orb orb-one" /><div className="orb orb-two" />
          <div className="brand-mark large"><Sparkles size={34} /></div>
          <div className="eyebrow"><Globe2 size={15} /> تواصل بلا حدود</div>
          <h1>NOVA <span>CHAT</span></h1>
          <p className="hero-copy">مساحتك الخاصة للتواصل، مشاركة اللحظات، والبقاء قريبًا مهما كانت المسافات.</p>
          <div className="feature-row"><span><ShieldCheck size={17} /> خصوصية وأمان</span><span><Wifi size={17} /> تواصل مباشر</span></div>
          <div className="floating-bubble bubble-a"><MessageCircle size={19} /></div>
          <div className="floating-bubble bubble-b"><Users size={19} /></div>
          <div className="floating-bubble bubble-c"><Video size={19} /></div>
        </div>
        <div className="auth-panel">
          <div className="panel-top"><span className="step-dot active" /><span className="step-dot" /><span className="step-dot" /></div>
          <div className="panel-icon"><LockKeyhole size={24} /></div>
          {!otpSent ? <>
            <div className="small-label">أهلاً بك من جديد</div>
            <h2>ابدأ رحلتك</h2>
            <p className="muted">أدخل رقم هاتفك وسنرسل لك رمز تحقق لمرة واحدة.</p>
            <form onSubmit={sendOtp} className="auth-form">
              <label className="field-label">رقم الهاتف</label>
              <PhoneInput
                international
                defaultCountry="EG"
                countryCallingCodeEditable={false}
                value={phone}
                onChange={setPhone}
                placeholder="أدخل رقم هاتفك"
                className="phone-control"
              />
              <div className="hint"><Globe2 size={14} /> اختر بلدك من القائمة واكتب الرقم بدون الصفر المحلي في البداية.</div>
              <button className="primary-btn" type="submit" disabled={busy || !phone}>
                {busy ? "جارٍ الإرسال..." : "إرسال رمز التحقق"} <ArrowLeft size={18} />
              </button>
            </form>
          </> : <>
            <div className="small-label">خطوة التحقق</div>
            <h2>أدخل رمز التحقق</h2>
            <p className="muted">أرسلنا رمزًا مكوّنًا من 6 أرقام إلى <bdi>{phone}</bdi></p>
            <form onSubmit={verifyOtp} className="auth-form">
              <label className="field-label">رمز OTP</label>
              <input className="otp-input" inputMode="numeric" autoComplete="one-time-code" maxLength={6}
                value={otp} onChange={(e) => setOtp(e.target.value.replace(/\D/g, "").slice(0, 6))}
                placeholder="••••••" />
              <button className="primary-btn" type="submit" disabled={busy || otp.length !== 6}>
                {busy ? "جارٍ التحقق..." : "تأكيد الرمز"} <Check size={18} />
              </button>
              <button type="button" className="text-btn" onClick={resendOtp} disabled={busy || seconds > 0}>
                {seconds > 0 ? `إعادة الإرسال بعد ${seconds} ثانية` : "إعادة إرسال الرمز"}
              </button>
              <button type="button" className="back-btn" onClick={() => { setOtpSent(false); setOtp(""); showMessage(""); }}>
                <ChevronLeft size={16} /> تغيير رقم الهاتف
              </button>
            </form>
          </>}
          {notice && <div className={`notice ${noticeError ? "error" : "success"}`}>{notice}</div>}
          <div className="secure-note"><ShieldCheck size={15} /> لن نشارك رقم هاتفك مع الآخرين.</div>
          <div className="copyright">NOVA CHAT · تواصل بثقة</div>
        </div>
      </section>
    </main>;
  }

  if (!profile?.display_name) {
    return <main className={`app-shell ${dark ? "dark" : "light"}`} dir="rtl">
      <div className="profile-card">
        <div className="brand-mark"><Sparkles size={28} /></div>
        <div className="small-label">تم التحقق من رقمك بنجاح</div>
        <h1>أهلاً بك في NOVA CHAT</h1>
        <p className="muted">اختر الاسم الذي سيظهر لأصدقائك داخل التطبيق.</p>
        <form onSubmit={saveProfile} className="auth-form">
          <label className="field-label">اسم العرض</label>
          <input className="name-input" value={displayName} onChange={(e) => setDisplayName(e.target.value)}
            maxLength={40} placeholder="اكتب اسمك" />
          <button className="primary-btn" disabled={profileBusy || displayName.trim().length < 2}>
            {profileBusy ? "جارٍ الحفظ..." : "حفظ والمتابعة"} <ArrowLeft size={18} />
          </button>
        </form>
        {notice && <div className={`notice ${noticeError ? "error" : "success"}`}>{notice}</div>}
      </div>
    </main>;
  }

  return <main className={`app-shell ${dark ? "dark" : "light"}`} dir="rtl">
    <header className="home-header">
      <div className="brand-inline"><div className="brand-mark"><Sparkles size={22} /></div><div><strong>NOVA CHAT</strong><small>تواصل بلا حدود</small></div></div>
      <div className="header-actions">
        <button className="icon-btn" onClick={() => setDark(!dark)} aria-label="تغيير المظهر">{dark ? <Sun /> : <Moon />}</button>
        <button className="logout-btn" onClick={logout}><LogOut size={17} /> خروج</button>
      </div>
    </header>
    <section className="home-content">
      <div className="welcome-card">
        <div><div className="small-label">مساحتك تبدأ من هنا</div><h1>أهلاً، {profile.display_name}</h1><p>تم تسجيل الدخول والتحقق من رقم هاتفك بنجاح.</p></div>
        <div className="welcome-icon"><MessageCircle size={34} /></div>
      </div>
      <div className="section-heading"><div><span className="small-label">ابقَ على تواصل</span><h2>المحادثات</h2></div><span className="online-badge"><i /> متصل</span></div>
      <div className="chat-list">
        {demoChats.map((chat) => <div className="chat-row" key={chat.name}>
          <div className={`avatar ${chat.color}`}>{chat.initials}</div>
          <div className="chat-info"><strong>{chat.name}</strong><span>{chat.message}</span></div>
          <time>{chat.time}</time>
        </div>)}
      </div>
      <div className="coming-soon"><Sparkles size={18} /><span>تم تجهيز تسجيل الدخول. ربط الرسائل الفعلية وجهات الاتصال هو المرحلة التالية.</span></div>
    </section>
    {notice && <div className={`notice floating-notice ${noticeError ? "error" : "success"}`}>{notice}</div>}
  </main>;
}