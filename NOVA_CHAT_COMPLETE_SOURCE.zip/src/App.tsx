import { useEffect, useMemo, useState } from 'react';
import type { FormEvent } from 'react';
import { Capacitor } from '@capacitor/core';
import { Contacts } from '@capacitor-community/contacts';
import type { Session } from '@supabase/supabase-js';
import { supabase, isSupabaseConfigured } from './lib/supabase';

type DeviceContact = {
  contactId?: string;
  name?: { display?: string; given?: string; family?: string };
  phones?: Array<{ number?: string; type?: string; label?: string }>;
};
type MatchedUser = { id: string; display_name: string | null; phone: string };

function normalizePhone(value: string): string {
  let digits = value.replace(/\D/g, '');
  if (digits.startsWith('00')) digits = digits.slice(2);
  if (digits.startsWith('0') && digits.length >= 10) digits = `20${digits.slice(1)}`;
  return digits ? `+${digits}` : '';
}

export default function App() {
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [phone, setPhone] = useState('+20');
  const [otp, setOtp] = useState('');
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const [contacts, setContacts] = useState<DeviceContact[]>([]);
  const [matches, setMatches] = useState<MatchedUser[]>([]);
  const [contactBusy, setContactBusy] = useState(false);
  const [displayName, setDisplayName] = useState('');
  const [tab, setTab] = useState<'chats' | 'contacts'>('chats');

  useEffect(() => {
    if (!supabase) { setLoading(false); return; }
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setLoading(false);
    });
    const { data } = supabase.auth.onAuthStateChange((_event, next) => setSession(next));
    return () => data.subscription.unsubscribe();
  }, []);

  const matchByPhone = useMemo(() => {
    const map = new Map<string, MatchedUser>();
    matches.forEach((m) => map.set(normalizePhone(m.phone), m));
    return map;
  }, [matches]);

  async function sendOtp(event: FormEvent) {
    event.preventDefault();
    if (!supabase) return;
    setBusy(true); setMessage('');
    const normalized = phone.trim();
    const { error } = await supabase.auth.signInWithOtp({ phone: normalized });
    setBusy(false);
    if (error) setMessage(error.message);
    else { setSent(true); setMessage('تم إرسال رمز التحقق إذا كان الرقم صالحًا ومفعّلًا.'); }
  }

  async function verifyOtp(event: FormEvent) {
    event.preventDefault();
    if (!supabase) return;
    setBusy(true); setMessage('');
    const { data, error } = await supabase.auth.verifyOtp({
      phone: phone.trim(), token: otp.trim(), type: 'sms'
    });
    if (error) { setBusy(false); setMessage(error.message); return; }
    if (data.user) {
      const { error: profileError } = await supabase.from('profiles').upsert({
        id: data.user.id,
        phone: data.user.phone ?? phone.trim(),
        display_name: displayName.trim() || 'مستخدم NOVA'
      }, { onConflict: 'id' });
      if (profileError) setMessage('تم التحقق، لكن تعذر حفظ الملف الشخصي: ' + profileError.message);
    }
    setBusy(false);
  }

  async function loadContacts() {
    if (!supabase || !session) return;
    if (!Capacitor.isNativePlatform()) {
      setMessage('قراءة جهات الاتصال متاحة من تطبيق Android المثبّت فقط.');
      return;
    }
    setContactBusy(true); setMessage('');
    try {
      const permission = await Contacts.checkPermissions();
      const granted = permission.contacts === 'granted';
      const requested = granted ? permission : await Contacts.requestPermissions();
      if (requested.contacts !== 'granted') {
        setMessage('لازم تسمح للتطبيق بالوصول إلى جهات الاتصال.');
        setContactBusy(false); return;
      }
      const result = await Contacts.getContacts({
        projection: {
          name: true,
          phones: true
        }
      });
      const list = (result.contacts ?? []) as DeviceContact[];
      setContacts(list);

      // يتم إرسال أرقام الهواتف فقط إلى Edge Function للمطابقة بعد موافقة المستخدم.
      const numbers = Array.from(new Set(
        list.flatMap((c) => (c.phones ?? [])
          .map((p) => normalizePhone(p.number ?? ''))
          .filter(Boolean))
      )).slice(0, 500);

      if (numbers.length) {
        const { data, error } = await supabase.functions.invoke('match-contacts', {
          body: { phoneNumbers: numbers }
        });
        if (error) throw error;
        setMatches((data?.matches ?? []) as MatchedUser[]);
      }
      setMessage(`تم تحميل ${list.length} جهة اتصال.`);
    } catch (error) {
      const text = error instanceof Error ? error.message : 'حدث خطأ أثناء قراءة جهات الاتصال.';
      setMessage(text);
    } finally {
      setContactBusy(false);
    }
  }

  async function signOut() {
    if (supabase) await supabase.auth.signOut();
    setContacts([]); setMatches([]);
  }

  if (loading) return <main className="center"><div className="spinner" /> جارٍ التحميل...</main>;

  if (!isSupabaseConfigured || !supabase) {
    return <main className="center"><section className="card"><Logo /><h1>إعداد NOVA غير مكتمل</h1><p>أضف VITE_SUPABASE_URL و VITE_SUPABASE_ANON_KEY في GitHub Secrets ثم أعد البناء.</p></section></main>;
  }

  if (!session) {
    return <main className="auth-shell">
      <section className="auth-card">
        <Logo />
        <h1>{sent ? 'تأكيد رقم الهاتف' : 'مرحبًا بك في NOVA'}</h1>
        <p className="muted">{sent ? 'اكتب رمز التحقق الذي وصلك برسالة SMS.' : 'سجّل الدخول برقم هاتفك للبدء.'}</p>
        {!sent ? <form onSubmit={sendOtp}>
          <label>رقم الهاتف بصيغة دولية</label>
          <input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+201xxxxxxxxx" dir="ltr" required />
          <label>اسمك (اختياري)</label>
          <input value={displayName} onChange={(e) => setDisplayName(e.target.value)} placeholder="الاسم الظاهر" />
          <button disabled={busy}>{busy ? 'جارٍ الإرسال...' : 'إرسال رمز التحقق'}</button>
        </form> : <form onSubmit={verifyOtp}>
          <label>رمز التحقق</label>
          <input value={otp} onChange={(e) => setOtp(e.target.value)} placeholder="123456" inputMode="numeric" dir="ltr" required />
          <button disabled={busy}>{busy ? 'جارٍ التحقق...' : 'تأكيد ودخول'}</button>
          <button className="secondary" type="button" onClick={() => { setSent(false); setOtp(''); }}>تغيير الرقم</button>
        </form>}
        {message && <p className="notice">{message}</p>}
        <small>باستمرارك، أنت توافق على استخدام رقم الهاتف لتسجيل الدخول.</small>
      </section>
    </main>;
  }

  return <main className="app-shell">
    <header className="topbar"><Logo /><button className="logout" onClick={signOut}>تسجيل الخروج</button></header>
    <nav className="tabs">
      <button className={tab === 'chats' ? 'active' : ''} onClick={() => setTab('chats')}>المحادثات</button>
      <button className={tab === 'contacts' ? 'active' : ''} onClick={() => setTab('contacts')}>جهات الاتصال</button>
    </nav>
    {tab === 'chats' ? <section className="content">
      <h2>أهلًا بك في NOVA 👋</h2>
      <div className="empty"><div className="bubble">✉</div><h3>مرحبًا بك في NOVA CHAT</h3><p>تم تسجيل الدخول بنجاح. نظام المحادثات الفعلية يحتاج إلى إعداد الجداول وسياسات قاعدة البيانات الخاصة بالرسائل.</p><button onClick={() => setTab('contacts')}>عرض جهات الاتصال</button></div>
    </section> : <section className="content">
      <div className="row"><div><h2>جهات الاتصال</h2><p className="muted">اعثر على أصدقائك الموجودين على NOVA.</p></div><button onClick={loadContacts} disabled={contactBusy}>{contactBusy ? 'جارٍ التحديث...' : 'تحديث'}</button></div>
      <p className="privacy">عند الضغط على تحديث، يقرأ التطبيق جهات اتصالك ويرسل أرقامها إلى خادم NOVA لمطابقة الحسابات. لن تُرفع أسماء جهات الاتصال.</p>
      {contacts.length === 0 ? <div className="empty"><div className="bubble">♙</div><h3>لم يتم تحميل جهات الاتصال</h3><p>اضغط تحديث واسمح للتطبيق بالوصول إلى جهات الاتصال.</p></div> :
        <div className="contact-list">{contacts.map((contact, index) => {
          const number = (contact.phones ?? []).map((p) => p.number ?? '').find(Boolean) ?? '';
          const name = contact.name?.display || [contact.name?.given, contact.name?.family].filter(Boolean).join(' ') || 'بدون اسم';
          const match = matchByPhone.get(normalizePhone(number));
          return <div className="contact" key={contact.contactId ?? `${name}-${index}`}>
            <div className="avatar">{name.slice(0, 1)}</div>
            <div className="contact-info"><strong>{name}</strong><small dir="ltr">{number}</small></div>
            {match ? <span className="badge">على NOVA</span> : <button className="invite" onClick={() => {
              const text = encodeURIComponent('جرّب NOVA CHAT للتواصل معي!');
              window.open(`https://wa.me/?text=${text}`, '_blank');
            }}>دعوة</button>}
          </div>;
        })}</div>}
    </section>}
    {message && <div className="toast">{message}</div>}
  </main>;
}

function Logo() {
  return <div className="logo"><span className="logo-mark">N</span><span>NOVA <b>CHAT</b></span></div>;
}