# NOVA CHAT — نسخة المصدر الكاملة

هذه نسخة مصدر React + Vite + TypeScript + Capacitor 7، وبها:
- تسجيل دخول إلزامي برقم الهاتف بصيغة دولية.
- إرسال OTP من 6 أرقام عبر Supabase Auth (ومزود Vonage الذي أعددته في Supabase).
- التحقق من الرمز قبل فتح واجهة التطبيق.
- حفظ جلسة تسجيل الدخول على الجهاز.
- إنشاء اسم عرض بعد أول تسجيل.
- واجهة عربية RTL مع وضع داكن/فاتح.
- إعداد Android عبر Capacitor.

## 1) مهم قبل البناء

لا تضع Vonage API Secret داخل التطبيق أو GitHub أو ملفات ZIP. احتفظ به داخل إعدادات مزود SMS في Supabase فقط.

يحتاج البناء إلى متغيرين من إعدادات Supabase:
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY` (أو publishable key)

أضفهما في GitHub:
Repository → Settings → Secrets and variables → Actions → New repository secret.

استخدم الاسمين أعلاه بالضبط. لا تستخدم `service_role` key مطلقًا في تطبيق الهاتف.

## 2) إعداد Supabase

1. افتح مشروع Supabase.
2. Authentication → Providers → Phone، وتأكد أن Phone مفعّل وأن إعداد Vonage محفوظ.
3. من Authentication → Settings، اجعل طول OTP ستة أرقام، واضبط مدة إعادة الإرسال ومعدل الطلبات بشكل آمن.
4. افتح SQL Editor.
5. انسخ وشغّل محتوى `supabase/schema.sql` مرة واحدة.

## 3) تعديل خطوة بناء GitHub Actions

داخل خطوة `Build Web Project` في ملف `.github/workflows/build.yml`، أضف `env` قبل `run` هكذا:

```yaml
      - name: Build Web Project
        env:
          VITE_SUPABASE_URL: ${{ secrets.VITE_SUPABASE_URL }}
          VITE_SUPABASE_ANON_KEY: ${{ secrets.VITE_SUPABASE_ANON_KEY }}
        run: |
          cd "$PROJECT_DIR"
          npm run build
```

احتفظ بباقي خطوات البناء الحالية. يجب أن يتم تنفيذ `npm run build` بعد استخراج ZIP والعثور على `package.json`.

## 4) اختبار التطبيق

- ثبّت APK.
- افتح NOVA CHAT.
- اختر الدولة من قائمة رمز الهاتف، واكتب الرقم بصيغة دولية.
- اطلب رمز التحقق، ثم أدخل رمز SMS.
- في أول دخول، اكتب اسم العرض.
- لن تفتح واجهة التطبيق قبل نجاح التحقق.

## 5) بناء محلي (اختياري)

```bash
npm install
npm run build
npx cap add android
npx cap sync android
```

ثم افتح مشروع Android أو ابنِ Debug APK باستخدام Gradle.

## ملاحظات مهمة

- هذه النسخة تنفذ تسجيل الهاتف والتحقق والملف الشخصي وواجهة بداية للمحادثات.
- قائمة المحادثات المعروضة حاليًا واجهة تمهيدية وليست مراسلة حقيقية بين المستخدمين بعد. الخطوة التالية هي بناء الجداول وسياسات RLS وإرسال/استقبال الرسائل لحظيًا.
- نجاح SMS عالميًا يعتمد على تغطية Vonage، البلد، شركة الاتصالات، ومتطلبات تسجيل Sender ID والقيود المحلية.
- لا تشارك API Secret أو رموز OTP مع أي شخص.
