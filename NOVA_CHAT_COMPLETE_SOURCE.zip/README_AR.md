# NOVA CHAT - نسخة جهات الاتصال

## محتويات النسخة
- React + TypeScript + Vite وCapacitor 7.
- تسجيل دخول برقم الهاتف والتحقق عبر OTP باستخدام Supabase.
- حفظ اسم المستخدم في جدول `profiles`.
- قراءة جهات اتصال Android بعد إذن المستخدم.
- مطابقة الأرقام مع حسابات NOVA CHAT من خلال دالة Supabase محدودة الطلبات.

## إعداد GitHub
احتفظ بالـ Repository Secrets التالية:
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`

لا تستخدم `service_role` ولا تضع Vonage API Secret في التطبيق أو GitHub.

## إعداد Supabase
افتح SQL Editor وشغّل محتوى `supabase/schema.sql` بالكامل. هذا يضيف/يحدّث جدول `profiles` ودالة `match_contacts` اللازمة لمطابقة جهات الاتصال.

## إعداد GitHub Actions
يوجد ملف `GITHUB_BUILD_WORKFLOW.yml` داخل ZIP. انسخ محتواه بالكامل إلى `.github/workflows/build.yml`. هذا الملف يضيف إذن Android لقراءة جهات الاتصال ويستخدم متغيرات Supabase أثناء البناء.

## البناء
يتطلب Node.js 22 و Java 21. بعد تحديث ZIP وملف workflow، شغّل GitHub Actions ونزّل APK الجديد.

## الخصوصية والملاحظات
- التطبيق يطلب إذن قراءة جهات الاتصال على الهاتف.
- عند اختيار تحديث جهات الاتصال، تُرسل الأرقام بصيغة دولية إلى Supabase لمطابقتها؛ لا تُرفع أسماء جهات الاتصال.
- دالة المطابقة تتطلب جلسة دخول، وتسمح بحد أقصى 300 رقم في الطلب و10 طلبات في الساعة لكل حساب.
- زر الدعوة يعرض تنبيهًا مؤقتًا؛ رابط دعوة/تثبيت عام لم يُضف بعد.
- المحادثات الحقيقية والمجموعات والمكالمات والإشعارات ليست مفعلة في هذه النسخة.


## إصلاح توافق إضافة جهات الاتصال
- استخدام `Contacts.checkPermissions()` و`Contacts.requestPermissions({ permissions: ["readContacts"] })`.
- تمرير خيارات الحقول إلى `Contacts.getContacts({ fields: [...] })`.
- عدم استيراد نوع `Contact` غير المصدّر؛ يتم تحويل النتيجة إلى نوع محلي متوافق مع حقول الهاتف والاسم.
