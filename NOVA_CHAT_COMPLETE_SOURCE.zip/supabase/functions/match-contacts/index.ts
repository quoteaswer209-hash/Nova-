import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  const json = (body: unknown, status = 200) =>
    new Response(JSON.stringify(body), { status, headers: { ...corsHeaders, "Content-Type": "application/json" } });

  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);

  const authorization = req.headers.get("Authorization");
  if (!authorization?.startsWith("Bearer ")) return json({ error: "Unauthorized" }, 401);

  const url = Deno.env.get("SUPABASE_URL")!;
  const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const jwt = authorization.slice("Bearer ".length);

  const userClient = createClient(url, anonKey, { global: { headers: { Authorization: `Bearer ${jwt}` } } });
  const { data: authData, error: authError } = await userClient.auth.getUser();
  if (authError || !authData.user) return json({ error: "Unauthorized" }, 401);

  const admin = createClient(url, serviceKey);
  const { count } = await admin.from("contact_match_requests")
    .select("*", { count: "exact", head: true })
    .eq("user_id", authData.user.id)
    .gte("created_at", new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString());

  if ((count ?? 0) >= 10) return json({ error: "Daily contact matching limit reached" }, 429);

  let body: { phoneNumbers?: unknown };
  try { body = await req.json(); } catch { return json({ error: "Invalid JSON" }, 400); }
  const numbers = Array.isArray(body.phoneNumbers)
    ? [...new Set(body.phoneNumbers.filter((v): v is string => typeof v === "string" && /^\+[1-9]\d{7,14}$/.test(v))]
    : [];

  if (numbers.length > 500) return json({ error: "Maximum 500 numbers per request" }, 400);

  await admin.from("contact_match_requests").insert({ user_id: authData.user.id });
  if (!numbers.length) return json({ matches: [] });

  const { data, error } = await admin.from("profiles")
    .select("id, display_name, phone")
    .in("phone", numbers)
    .neq("id", authData.user.id);

  if (error) return json({ error: "Matching failed" }, 500);
  return json({ matches: data ?? [] });
});