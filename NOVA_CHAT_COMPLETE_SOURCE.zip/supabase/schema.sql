-- NOVA CHAT profiles and privacy-limited contact matching
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name TEXT NOT NULL,
  phone TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS phone TEXT;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "profile_select" ON public.profiles;
CREATE POLICY "profile_select" ON public.profiles FOR SELECT TO authenticated USING (auth.uid() = id);
DROP POLICY IF EXISTS "profile_insert" ON public.profiles;
CREATE POLICY "profile_insert" ON public.profiles FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);
DROP POLICY IF EXISTS "profile_update" ON public.profiles;
CREATE POLICY "profile_update" ON public.profiles FOR UPDATE TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

CREATE TABLE IF NOT EXISTS public.contact_match_limits (
  user_id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  window_started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  request_count INTEGER NOT NULL DEFAULT 0
);
REVOKE ALL ON public.contact_match_limits FROM anon, authenticated;

CREATE OR REPLACE FUNCTION public.match_contacts(p_phones TEXT[])
RETURNS TABLE(phone TEXT, display_name TEXT)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth
AS $$
DECLARE
  v_user UUID := auth.uid();
  v_count INTEGER;
  v_window TIMESTAMPTZ;
BEGIN
  IF v_user IS NULL THEN
    RAISE EXCEPTION 'Authentication required';
  END IF;
  IF COALESCE(array_length(p_phones, 1), 0) > 300 THEN
    RAISE EXCEPTION 'Maximum 300 contacts per request';
  END IF;

  INSERT INTO public.contact_match_limits(user_id, window_started_at, request_count)
  VALUES (v_user, NOW(), 1)
  ON CONFLICT (user_id) DO UPDATE SET
    window_started_at = CASE
      WHEN public.contact_match_limits.window_started_at < NOW() - INTERVAL '1 hour' THEN NOW()
      ELSE public.contact_match_limits.window_started_at
    END,
    request_count = CASE
      WHEN public.contact_match_limits.window_started_at < NOW() - INTERVAL '1 hour' THEN 1
      ELSE public.contact_match_limits.request_count + 1
    END
  RETURNING request_count, window_started_at INTO v_count, v_window;

  IF v_count > 10 THEN
    RAISE EXCEPTION 'Contact matching rate limit reached. Try again later.';
  END IF;

  RETURN QUERY
    SELECT p.phone, p.display_name
    FROM public.profiles AS p
    WHERE p.phone = ANY(COALESCE(p_phones, ARRAY[]::TEXT[]))
      AND p.id <> v_user
      AND p.phone IS NOT NULL;
END;
$$;

REVOKE ALL ON FUNCTION public.match_contacts(TEXT[]) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.match_contacts(TEXT[]) TO authenticated;
NOTIFY pgrst, 'reload schema';
