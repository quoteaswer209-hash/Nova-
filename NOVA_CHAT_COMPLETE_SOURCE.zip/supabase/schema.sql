-- Run this entire file in Supabase SQL Editor.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'مستخدم NOVA',
  phone text unique,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;

drop policy if exists "profile_select_own" on public.profiles;
create policy "profile_select_own" on public.profiles
for select to authenticated using (auth.uid() = id);

drop policy if exists "profile_insert_own" on public.profiles;
create policy "profile_insert_own" on public.profiles
for insert to authenticated with check (auth.uid() = id);

drop policy if exists "profile_update_own" on public.profiles;
create policy "profile_update_own" on public.profiles
for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

-- The Edge Function uses service role to match contacts; this table is not exposed to clients.
create table if not exists public.contact_match_requests (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);
alter table public.contact_match_requests enable row level security;
revoke all on public.contact_match_requests from anon, authenticated;

-- A trigger ensures new OTP users get a profile row. The app updates display_name/phone after OTP.
create or replace function public.handle_new_nova_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, phone, display_name)
  values (new.id, new.phone, 'مستخدم NOVA')
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_nova on auth.users;
create trigger on_auth_user_created_nova
after insert on auth.users
for each row execute procedure public.handle_new_nova_user();