import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.nova.chat',
  appName: 'NOVA CHAT',
  webDir: 'dist'
};

export default config;
