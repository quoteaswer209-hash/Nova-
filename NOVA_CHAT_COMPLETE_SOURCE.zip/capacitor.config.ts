import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.novachat.app",
  appName: "NOVA CHAT",
  webDir: "dist"
};

export default config;
