#!/usr/bin/env bash
set -euo pipefail

MANIFEST="android/app/src/main/AndroidManifest.xml"
if [ ! -f "$MANIFEST" ]; then
  echo "ERROR: AndroidManifest.xml not found at $MANIFEST"
  exit 1
fi

if ! grep -q 'android.permission.READ_CONTACTS' "$MANIFEST"; then
  sed -i 's#</manifest>#    <uses-permission android:name="android.permission.READ_CONTACTS" />\n    <uses-permission android:name="android.permission.WRITE_CONTACTS" />\n</manifest>#' "$MANIFEST"
fi

echo "Contacts permissions added to $MANIFEST"
grep -E 'android.permission.(READ|WRITE)_CONTACTS' "$MANIFEST"
