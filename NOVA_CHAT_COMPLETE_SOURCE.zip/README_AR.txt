NOVA CHAT - نسخة إعادة إنشاء أولية

1) ارفع هذا الملف باسم NOVA_CHAT_COMPLETE_SOURCE.zip إلى جذر مستودع GitHub.
2) انسخ build.yml إلى المستودع في المسار: .github/workflows/build.yml
3) أضف GitHub Secrets:
   VITE_SUPABASE_URL
   VITE_SUPABASE_ANON_KEY
4) في Supabase SQL Editor شغّل محتوى supabase/schema.sql.
5) انشر Edge Function باسم match-contacts:
   supabase functions deploy match-contacts
   وتأكد أن أسرار SUPABASE_URL وSUPABASE_ANON_KEY وSUPABASE_SERVICE_ROLE_KEY متاحة للدالة.
   لا تضع SERVICE_ROLE_KEY في التطبيق أو GitHub Actions أو ملف ZIP.
6) شغّل GitHub Actions ثم نزّل Artifact باسم NOVA-CHAT-APK.

ملاحظات مهمة:
- هذه نسخة جديدة مبنية من الصفر وليست نسخة مطابقة لمشروعك القديم؛ ملفات المشروع القديم لم تكن متاحة.
- تسجيل OTP يحتاج تفعيل Phone Auth وإعداد مزود SMS في Supabase (مثل Vonage) بشكل صحيح.
- مطابقة جهات الاتصال تتطلب نشر Edge Function وتشغيل SQL أولًا. قراءة الأسماء والأرقام تستخدم projection (name و phones) وفق واجهة الإضافة. التطبيق يوضح للمستخدم أن أرقام جهات الاتصال تُرسل للمطابقة، ولا يرفع أسماء جهات الاتصال.
- هذه النسخة لا تحتوي بعد على نظام محادثات ورسائل فعلي؛ الشاشة الرئيسية توضح ذلك.
- لا يوجد APK جاهز داخل ZIP؛ GitHub Actions يبنيه بعد إعداد المتطلبات.


إصلاح إذن جهات الاتصال في Android:
- ملف build.yml يشغّل scripts/add-contact-permissions.sh بعد إنشاء مشروع Android.
- السكربت يضيف READ_CONTACTS و WRITE_CONTACTS إلى AndroidManifest.xml تلقائيًا قبل بناء APK.
- بعد رفع ZIP الجديد وتشغيل Actions، ثبّت APK الجديد ووافق على إذن جهات الاتصال عند ظهوره.
